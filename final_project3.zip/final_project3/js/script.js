// نصوص الترجمة للعربي والانجليزي
const langData = {
    ar: {
        app_name: "طلابي",
        app_subtitle: "نظام إدارة الطلاب",
        main_menu: "القائمة الرئيسية",
        nav_dashboard: "لوحة التحكم",
        nav_students: "الطلاب",
        nav_add_student: "إضافة طالب",
        role_admin: "مدير النظام",
        theme_light: "الوضع النهاري",
        theme_dark: "الوضع الليلي",
        welcome_login_title: 'مرحباً بك في منصة "طلابي" الرقمية',
        srv_1_title: "إدارة شاملة لسجلات الطلاب",
        srv_1_desc: "إضافة، استعراض، تحديث، وحذف بيانات الطلاب مع أرشفة الصور الشخصية.",
        srv_2_title: "بحث فوري وترقيم ذكي للصفحات",
        srv_2_desc: "فلترة فورية للطلاب بالاسم أو البريد أو الهاتف مع عرض منظم .",
        srv_3_title: "حماية متقدمة وتحقق فوري",
        srv_3_desc: "تشفير كامل لكلمات المرور وتحقق لحظي من صحة البيانات المدخلة دون إعادة تحميل الصفحة.",
        login_header: "تسجيل الدخول إلى لوحة التحكم",
        login_sub: "أدخل بيانات حسابك للوصول إلى خدمات النظام",
        lbl_user_email: "اسم المستخدم أو البريد الإلكتروني",
        lbl_username: "اسم المستخدم",
        lbl_email: "البريد الإلكتروني",
        lbl_password: "كلمة المرور",
        lbl_confirm_pass: "تأكيد كلمة المرور",
        btn_login: "دخول إلى لوحة التحكم",
        no_account: "ليس لديك حساب مدير؟",
        create_account: "إنشاء حساب جديد",
        reg_title: "إنشاء حساب مدير جديد",
        reg_sub: "سجّل حسابك للتمكن من إدارة بيانات الطلاب",
        btn_register: "إنشاء الحساب",
        have_account: "لديك حساب بالفعل؟",
        login_now: "تسجيل الدخول",
        dash_welcome: "مرحبا بك في لوحة التحكم",
        dash_sub: "نظرة عامة وإحصائيات حية مرتبطة بقاعدة البيانات",
        btn_add_new_student: "إضافة طالب جديد",
        stat_total: "إجمالي الطلاب المسجلين",
        stat_recent: "المضافون حديثا (آخر 24 ساعة)",
        stat_status: "حالة قاعدة البيانات",
        stat_online: "متصل ومحدث تلقائيا",
        quick_access: "الوصول السريع لإدارة سجلات الطلاب",
        qa_view_title: "قائمة الطلاب والبحث ",
        qa_view_desc: "استعراض الطلاب، الفلترة، التعديل، أو الحذف",
        qa_add_title: "تسجيل طالب جديد ",
        qa_add_desc: "إدخال بيانات طالب مع التحقق الفوري ",
        lbl_std_name: "اسم الطالب الكامل",
        lbl_phone: "رقم الهاتف",
        lbl_pic: "الصورة الشخصية",
        lbl_address: "العنوان بالتفصيل",
        btn_save: "حفظ بيانات الطالب",
        btn_search: "بحث"
    },
    en: {
        app_name: "Tollabi",
        app_subtitle: "Student Management System",
        main_menu: "Main Menu",
        nav_dashboard: "Dashboard",
        nav_students: "Students",
        nav_add_student: "Add Student",
        role_admin: "System Admin",
        theme_light: "Light Mode",
        theme_dark: "Dark Mode",
        welcome_login_title: 'Welcome to "Tollabi" Platform',
        welcome_login_desc: "Smart platform for managing academic records and student data with security and speed:",
        srv_1_title: "Complete Student Records ",
        srv_1_desc: "Add, view, update, and delete student records with profile pictures.",
        srv_2_title: "Instant Search & Pagination",
        srv_2_desc: "Filter students by name, email, or phone.",
        srv_3_title: "Security & Real-Time AJAX Validation",
        srv_3_desc: "Password hashing and instant form validation without page reload.",
        login_header: "Sign In to Dashboard",
        login_sub: "Enter your account details to continue",
        lbl_user_email: "Username or Email",
        lbl_username: "Username",
        lbl_email: "Email Address",
        lbl_password: "Password",
        lbl_confirm_pass: "Confirm Password",
        btn_login: "Login",
        no_account: "Don't have an account?",
        create_account: "Create Account",
        reg_title: "Create New Admin Account",
        reg_sub: "Register your account to manage students",
        btn_register: "Register",
        have_account: "Already have an account?",
        login_now: "Sign In",
        dash_welcome: "Welcome to Dashboard",
        dash_sub: "Live overview and stats from database",
        btn_add_new_student: "Add New Student",
        stat_total: "Total Registered Students",
        stat_recent: "Added Recently (Last 24h)",
        stat_status: "Database Status",
        stat_online: "Connected & Updated",
        quick_access: "Quick Access",
        qa_view_title: "Students List & Search",
        qa_view_desc: "View, search, update, or delete students",
        qa_add_title: "Register New Student",
        qa_add_desc: "Add student ",
        lbl_std_name: "Full Name",
        lbl_phone: "Phone Number",
        lbl_pic: "Profile Picture",
        lbl_address: "Address",
        btn_save: "Save Student",
        btn_search: "Search"
    }
};

document.addEventListener("DOMContentLoaded", function () {

    // زر القائمة الجانبية للجوال
    const sidebar = document.querySelector(".sidebar");
    const topBar = document.querySelector(".top-bar");

    if (sidebar && topBar) {
        const menuBtn = document.createElement("button");
        menuBtn.type = "button";
        menuBtn.className = "menu-toggle-btn";
        menuBtn.innerHTML = '<i class="bi bi-list"></i>';
        topBar.prepend(menuBtn);

        const overlay = document.createElement("div");
        overlay.className = "dark-overlay";
        document.body.appendChild(overlay);

        function toggleMenu() {
            sidebar.classList.toggle("open");
            overlay.classList.toggle("show");
        }

        menuBtn.addEventListener("click", toggleMenu);
        overlay.addEventListener("click", toggleMenu);
    }

    // تبديل الوضع الليلي والنهاري
    const htmlTag = document.documentElement;
    const themeBtn = document.getElementById("themeToggleBtn");
    const themeIcon = document.getElementById("themeIcon");
    const themeText = document.getElementById("themeText");

    let savedTheme = localStorage.getItem("theme_mode") || "dark";
    let savedLang = localStorage.getItem("site_lang") || "ar";

    function setTheme(mode) {
        htmlTag.setAttribute("data-bs-theme", mode);
        localStorage.setItem("theme_mode", mode);
        if (themeIcon && themeText) {
            if (mode === "dark") {
                themeIcon.className = "bi bi-sun-fill text-warning";
                themeText.textContent = langData[savedLang].theme_light;
            } else {
                themeIcon.className = "bi bi-moon-stars-fill text-secondary";
                themeText.textContent = langData[savedLang].theme_dark;
            }
        }
    }

    if (themeBtn) {
        themeBtn.addEventListener("click", function () {
            savedTheme = savedTheme === "dark" ? "light" : "dark";
            setTheme(savedTheme);
        });
    }

    // تبديل اللغة عربي / انجليزي
    const langBtn = document.getElementById("langToggleBtn");
    const langFlag = document.getElementById("langFlag");
    const langText = document.getElementById("langText");

    function setLanguage(lang) {
        savedLang = lang;
        localStorage.setItem("site_lang", lang);

        htmlTag.lang = lang;
        htmlTag.dir = lang === "ar" ? "rtl" : "ltr";

        document.querySelectorAll("[data-i18n]").forEach(item => {
            const key = item.getAttribute("data-i18n");
            if (langData[lang][key]) {
                item.textContent = langData[lang][key];
            }
        });

        if (langFlag && langText) {
            if (lang === "ar") {
                langFlag.src = "https://flagcdn.com/w40/us.png";
                langText.textContent = "English";
            } else {
                langFlag.src = "https://flagcdn.com/w40/sy.png";
                langText.textContent = "العربية";
            }
        }

        setTheme(savedTheme);
    }

    if (langBtn) {
        langBtn.addEventListener("click", function () {
            const newLang = savedLang === "ar" ? "en" : "ar";
            setLanguage(newLang);
        });
    }

    setLanguage(savedLang);

    // تحديث اسم المدير والإحصائيات
    const params = new URLSearchParams(window.location.search);

    if (params.has("login_success")) {
        sessionStorage.setItem("logged_in", "true");
        if (params.has("user")) {
            sessionStorage.setItem("admin_user", params.get("user"));
        }
    }

    if (params.has("logged_out")) {
        sessionStorage.removeItem("logged_in");
        sessionStorage.removeItem("admin_user");
    }

    function showAdminName(name) {
        const nameTag = document.getElementById("currentUserName");
        const avatarTag = document.getElementById("currentUserAvatar");
        if (nameTag && name) {
            nameTag.textContent = name;
        }
        if (avatarTag && name) {
            const words = name.trim().split(" ");
            const letters = words.length > 1
                ? words[0].charAt(0) + " " + words[1].charAt(0)
                : name.trim().substring(0, 2);
            avatarTag.textContent = letters.toUpperCase();
        }
    }

    const currentAdmin = sessionStorage.getItem("admin_user");
    if (currentAdmin) {
        showAdminName(currentAdmin);
    }

    const logoutBtn = document.getElementById("logoutBtn");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", function () {
            sessionStorage.removeItem("logged_in");
            sessionStorage.removeItem("admin_user");
        });
    }

    // جلب أرقام الطلاب في لوحة التحكم
    if (document.body.classList.contains("protected-page")) {
        fetch("stats_api.php")
            .then(res => res.json())
            .then(data => {
                if (data.authenticated === false) {
                    window.location.replace("login.html?auth_required=1");
                    return;
                }
                sessionStorage.setItem("logged_in", "true");
                sessionStorage.setItem("admin_user", data.username);
                showAdminName(data.username);

                const totalNum = document.getElementById("statTotalStudents");
                const recentNum = document.getElementById("statRecentStudents");
                if (totalNum) totalNum.textContent = data.total_students;
                if (recentNum) recentNum.textContent = data.recent_students;
            })
            .catch(() => {
                if (sessionStorage.getItem("logged_in") !== "true") {
                    window.location.replace("login.html?auth_required=1");
                }
            });
    }

    //صفحة تسجيل الدخول
    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        const errBox = document.getElementById("loginError");
        const errText = document.getElementById("loginErrorText");

        if (params.has("auth_required")) {
            errText.textContent = "يرجى تسجيل الدخول أولاً للوصول إلى لوحة التحكم.";
            errBox.classList.remove("d-none");
        } else if (params.has("error")) {
            errText.textContent = "اسم المستخدم أو كلمة المرور غير صحيحة!";
            errBox.classList.remove("d-none");
        } else if (params.has("registered")) {
            errBox.className = "alert alert-success py-2 small";
            errText.textContent = "تم إنشاء الحساب بنجاح! يمكنك تسجيل الدخول الآن.";
            errBox.classList.remove("d-none");
        }

        loginForm.addEventListener("submit", function (e) {
            const u = document.getElementById("username_email").value.trim();
            const p = document.getElementById("password").value.trim();
            if (!u || !p) {
                e.preventDefault();
                errBox.className = "alert alert-danger py-2 small";
                errText.textContent = "يرجى إدخال اسم المستخدم وكلمة المرور.";
                errBox.classList.remove("d-none");
            }
        });
    }

    // التحقق من صفحة إنشاء حساب
    const registerForm = document.getElementById("registerForm");
    if (registerForm) {
        const alertBox = document.getElementById("registerAlert");

        if (params.get("error") === "exists") {
            alertBox.className = "alert alert-danger py-2 small";
            alertBox.textContent = "اسم المستخدم أو البريد الإلكتروني مسجل مسبقاً!";
            alertBox.classList.remove("d-none");
        }

        registerForm.addEventListener("submit", function (e) {
            const user = document.getElementById("reg_username").value.trim();
            const mail = document.getElementById("reg_email").value.trim();
            const pass1 = document.getElementById("reg_password").value;
            const pass2 = document.getElementById("reg_confirm_password").value;
            const mailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!user || !mail || !pass1 || !pass2) {
                e.preventDefault();
                alertBox.className = "alert alert-danger py-2 small";
                alertBox.textContent = "جميع الحقول مطلوبة.";
                alertBox.classList.remove("d-none");
            } else if (!mailPattern.test(mail)) {
                e.preventDefault();
                alertBox.className = "alert alert-danger py-2 small";
                alertBox.textContent = "صيغة البريد الإلكتروني غير صحيحة.";
                alertBox.classList.remove("d-none");
            } else if (pass1.length < 6) {
                e.preventDefault();
                alertBox.className = "alert alert-warning py-2 small";
                alertBox.textContent = "كلمة المرور يجب أن تكون 6 محارف على الأقل.";
                alertBox.classList.remove("d-none");
            } else if (pass1 !== pass2) {
                e.preventDefault();
                alertBox.className = "alert alert-danger py-2 small";
                alertBox.textContent = "كلمتا المرور غير متطابقتين!";
                alertBox.classList.remove("d-none");
            }
        });
    }

    // التحقق الفوري AJAX في صفحة إضافة طالب
    const addForm = document.getElementById("addStudentForm");
    if (addForm) {
        const nameIn = document.getElementById("name");
        const emailIn = document.getElementById("email");
        const phoneIn = document.getElementById("phone");
        const addressIn = document.getElementById("address");
        const msgBox = document.getElementById("ajaxAlert");
        const mailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        function checkInput(el, isOk) {
            if (!isOk) {
                el.classList.add("is-invalid");
                el.classList.remove("is-valid");
                return false;
            } else {
                el.classList.remove("is-invalid");
                el.classList.add("is-valid");
                return true;
            }
        }

        nameIn.addEventListener("input", () => checkInput(nameIn, nameIn.value.trim() !== ""));
        emailIn.addEventListener("input", () => checkInput(emailIn, mailPattern.test(emailIn.value.trim())));
        phoneIn.addEventListener("input", () => checkInput(phoneIn, phoneIn.value.trim().length >= 8));
        addressIn.addEventListener("input", () => checkInput(addressIn, addressIn.value.trim() !== ""));

        addForm.addEventListener("submit", function (e) {
            e.preventDefault();

            const ok1 = checkInput(nameIn, nameIn.value.trim() !== "");
            const ok2 = checkInput(emailIn, mailPattern.test(emailIn.value.trim()));
            const ok3 = checkInput(phoneIn, phoneIn.value.trim().length >= 8);
            const ok4 = checkInput(addressIn, addressIn.value.trim() !== "");

            if (!ok1 || !ok2 || !ok3 || !ok4) {
                msgBox.className = "alert alert-danger";
                msgBox.textContent = "يرجى التأكد من ملء جميع الحقول بشكل صحيح.";
                msgBox.classList.remove("d-none");
                return;
            }

            const formData = new FormData(addForm);

            fetch("add_student.php", {
                method: "POST",
                body: formData,
                headers: { "X-Requested-With": "XMLHttpRequest" }
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === "success") {
                    msgBox.className = "alert alert-success";
                    msgBox.textContent = data.message;
                    msgBox.classList.remove("d-none");
                    addForm.reset();
                    [nameIn, emailIn, phoneIn, addressIn].forEach(el => el.classList.remove("is-valid"));
                } else {
                    msgBox.className = "alert alert-danger";
                    msgBox.textContent = data.message || "حدث خطأ أثناء الحفظ.";
                    msgBox.classList.remove("d-none");
                }
            })
            .catch(() => {
                msgBox.className = "alert alert-danger";
                msgBox.textContent = "خطأ في الاتصال مع السيرفر.";
                msgBox.classList.remove("d-none");
            });
        });
    }
});

// رسالة تأكيد الحذف
function confirmDelete(event, id, name) {
    if (!confirm("هل أنت متأكد من حذف الطالب: " + name + " ؟")) {
        event.preventDefault();
        return false;
    }
    return true;
}